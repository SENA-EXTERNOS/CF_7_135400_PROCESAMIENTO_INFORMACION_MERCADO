function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6TqwAVraAmW":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

