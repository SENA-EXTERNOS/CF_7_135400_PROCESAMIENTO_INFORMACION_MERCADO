function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5W9DY8KIJc4":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

