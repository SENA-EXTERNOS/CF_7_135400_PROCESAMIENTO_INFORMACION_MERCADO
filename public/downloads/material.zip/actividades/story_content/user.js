function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5xwLi3cEdAn":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

